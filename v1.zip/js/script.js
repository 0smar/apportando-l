window.sr = ScrollReveal();
sr.reveal('.logo');
sr.reveal('.slogan');
sr.reveal('.description');
sr.reveal('.graphi');
sr.reveal('.circlei');
sr.reveal('.moo');
sr.reveal('.form');
sr.reveal('.fimg');